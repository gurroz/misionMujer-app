//
//  SplashScreenController.swift
//  MisionMujer
//
//  Created by Gonzalo Urroz on 12/9/18.
//  Copyright © 2018 Gonzalo Urroz. All rights reserved.
//

import UIKit

class SplashScreenController: UIViewController {

}
